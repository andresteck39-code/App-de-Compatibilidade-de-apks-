package com.apkpatcher.service

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import com.apkpatcher.model.ShellResult
import com.apkpatcher.model.ShizukuConnectionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * ShizukuManager - Gerencia conexão com Shizuku e execução de comandos
 * via Binder IPC com privilégios de ADB Shell (uid=2000)
 */
class ShizukuManager(private val context: Context) {

    companion object {
        private const val TAG = "ShizukuManager"
        private const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001
        private const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    }

    private val _connectionState = MutableStateFlow(ShizukuConnectionState())
    val connectionState: StateFlow<ShizukuConnectionState> = _connectionState

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku Binder received")
        updateConnectionState()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.w(TAG, "Shizuku Binder dead")
        _connectionState.value = ShizukuConnectionState()
    }

    private val requestPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
            updateConnectionState()
            Log.d(TAG, "Permission result: $grantResult")
        }
    }

    init {
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(requestPermissionListener)
    }

    private fun updateConnectionState() {
        val isInstalled = isShizukuInstalled()
        val isRunning = try { Shizuku.getBinder() != null } catch (e: Exception) { false }
        val hasPermission = try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) { false }
        val version = try { Shizuku.getVersion() } catch (e: Exception) { 0 }

        _connectionState.value = ShizukuConnectionState(
            isInstalled = isInstalled,
            isRunning = isRunning,
            hasPermission = hasPermission,
            version = version
        )
        Log.d(TAG, "State: installed=$isInstalled, running=$isRunning, perm=$hasPermission, v=$version")
    }

    fun isShizukuInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) { false }
    }

    fun requestPermission() {
        if (!Shizuku.shouldShowRequestPermissionRationale()) {
            Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
        }
    }

    fun hasPermission(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) { false }
    }

    fun isAvailable(): Boolean {
        return _connectionState.value.let {
            it.isRunning && it.hasPermission
        }
    }

    /**
     * Executa comando shell via Shizuku Binder (uid=2000 / ADB Shell)
     * Usa ShizukuRemoteProcess para execução nativa com privilégios elevados
     */
    suspend fun executeCommand(command: String): ShellResult = withContext(Dispatchers.IO) {
        if (!isAvailable()) {
            return@withContext ShellResult.Error("Shizuku não disponível ou sem permissão", -1)
        }

        try {
            Log.d(TAG, "Executing via Shizuku Binder: $command")

            val process: ShizukuRemoteProcess = Shizuku.newProcess(
                arrayOf("sh", "-c", command),
                null,
                null
            )

            val stdout = BufferedReader(InputStreamReader(process.inputStream))
            val stderr = BufferedReader(InputStreamReader(process.errorStream))

            val output = StringBuilder()
            val errors = StringBuilder()

            // Leitura de stdout
            var line: String?
            while (stdout.readLine().also { line = it } != null) {
                output.appendLine(line)
            }

            // Leitura de stderr
            while (stderr.readLine().also { line = it } != null) {
                errors.appendLine(line)
            }

            val exitCode = process.waitFor()
            process.destroy()

            val outStr = output.toString().trimEnd()
            val errStr = errors.toString().trimEnd()

            Log.d(TAG, "Exit: $exitCode, out=$outStr, err=$errStr")

            return@withContext if (exitCode == 0 || outStr.contains("Success", ignoreCase = true)) {
                ShellResult.Success(if (outStr.isNotEmpty()) outStr else errStr, exitCode)
            } else {
                ShellResult.Error(if (errStr.isNotEmpty()) errStr else outStr, exitCode)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Shizuku exec error", e)
            ShellResult.Error("Erro ao executar: ${e.message}", -1)
        }
    }

    /**
     * Instala APK via pm install com flags de bypass para Android 15
     */
    suspend fun installApk(
        apkPath: String,
        config: com.apkpatcher.model.PatchConfig
    ): ShellResult = withContext(Dispatchers.IO) {
        val flags = buildPmInstallFlags(config)
        val command = "pm install $flags \"$apkPath\""
        Log.d(TAG, "Install command: $command")
        executeCommand(command)
    }

    /**
     * Instala APK em sessão (para APKs divididos/split)
     */
    suspend fun installApkSession(
        apkPaths: List<String>,
        config: com.apkpatcher.model.PatchConfig
    ): ShellResult = withContext(Dispatchers.IO) {
        try {
            // Cria sessão de instalação
            val createResult = executeCommand("pm install-create -t -g")
            if (createResult is ShellResult.Error) return@withContext createResult

            val sessionIdRegex = Regex("\\[(\\d+)\\]")
            val sessionId = sessionIdRegex.find((createResult as ShellResult.Success).output)
                ?.groupValues?.get(1)
                ?: return@withContext ShellResult.Error("Falha ao criar sessão pm", -1)

            // Adiciona cada APK na sessão
            apkPaths.forEachIndexed { index, path ->
                val writeResult = executeCommand(
                    "pm install-write -S ${java.io.File(path).length()} $sessionId split_$index \"$path\""
                )
                if (writeResult is ShellResult.Error) {
                    executeCommand("pm install-abandon $sessionId")
                    return@withContext writeResult
                }
            }

            // Commita a sessão
            val commitResult = executeCommand("pm install-commit $sessionId")
            commitResult

        } catch (e: Exception) {
            ShellResult.Error("Erro na sessão de instalação: ${e.message}", -1)
        }
    }

    /**
     * Desinstala pacote preservando dados se solicitado
     */
    suspend fun uninstallPackage(packageName: String, keepData: Boolean): ShellResult {
        val flag = if (keepData) "-k" else ""
        return executeCommand("pm uninstall $flag $packageName")
    }

    /**
     * Obtém informações de pacote instalado
     */
    suspend fun getPackageInfo(packageName: String): ShellResult {
        return executeCommand("dumpsys package $packageName")
    }

    /**
     * Lista todos os pacotes instalados
     */
    suspend fun listPackages(filter: String = ""): ShellResult {
        return if (filter.isNotEmpty()) {
            executeCommand("pm list packages | grep $filter")
        } else {
            executeCommand("pm list packages")
        }
    }

    /**
     * Reseta permissões de app (útil após instalação)
     */
    suspend fun resetPermissions(packageName: String): ShellResult {
        return executeCommand("pm reset-permissions $packageName")
    }

    /**
     * Concede permissão específica via pm grant
     */
    suspend fun grantPermission(packageName: String, permission: String): ShellResult {
        return executeCommand("pm grant $packageName $permission")
    }

    /**
     * Força instalação sem verificação de assinatura via settings
     */
    suspend fun disableVerification(): ShellResult {
        return executeCommand("settings put global verifier_verify_adb_installs 0")
    }

    /**
     * Habilita instalação de fontes desconhecidas globalmente
     */
    suspend fun enableUnknownSources(): ShellResult {
        return executeCommand("settings put global install_non_market_apps 1")
    }

    /**
     * Constrói flags pm install para Android 15 com bypass máximo
     */
    private fun buildPmInstallFlags(config: com.apkpatcher.model.PatchConfig): String {
        return buildString {
            append("-t ")          // Permite APKs de teste
            append("-g ")          // Concede todas as permissões runtime
            append("-r ")          // Reinstala preservando dados

            if (config.allowDowngrade) {
                append("-d ")      // Permite downgrade de versão
            }
            if (config.disableVerification) {
                append("--no-streaming ")   // Evita streaming install
            }
            if (config.bypassRestrictedPermissions) {
                append("--restrict-permissions ")
            }
            if (config.forceQueryable) {
                append("--force-queryable ")
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                append("--bypass-low-target-sdk-block ")
            }
        }.trim()
    }

    fun cleanup() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(requestPermissionListener)
    }
}
