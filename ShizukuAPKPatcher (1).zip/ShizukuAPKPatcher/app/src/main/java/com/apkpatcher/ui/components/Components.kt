package com.apkpatcher.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apkpatcher.model.LogEntry
import com.apkpatcher.model.LogLevel
import com.apkpatcher.ui.theme.*

// ── Terminal Card ────────────────────────────────────────────────────────

@Composable
fun TerminalCard(
    modifier: Modifier = Modifier,
    title: String? = null,
    glowColor: Color = NeonGreen,
    content: @Composable ColumnScope.() -> Unit
) {
    val glowAlpha by rememberInfiniteTransition(label = "glow").animateFloat(
        initialValue = 0.3f, targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "glow"
    )

    Box(modifier = modifier) {
        // Glow border effect
        Box(
            modifier = Modifier
                .matchParentSize()
                .drawBehind {
                    drawRoundRect(
                        color = glowColor.copy(alpha = glowAlpha * 0.3f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(12.dp.toPx()),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardDark),
            border = BorderStroke(1.dp, glowColor.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                if (title != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(glowColor, RoundedCornerShape(4.dp))
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = title.uppercase(),
                            color = glowColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                }
                content()
            }
        }
    }
}

// ── Status Indicator ─────────────────────────────────────────────────────

@Composable
fun StatusDot(
    active: Boolean,
    activeColor: Color = NeonGreen,
    modifier: Modifier = Modifier
) {
    val alpha by rememberInfiniteTransition(label = "dot").animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = if (active) infiniteRepeatable(
            tween(800), RepeatMode.Reverse
        ) else infiniteRepeatable(tween(3000), RepeatMode.Reverse),
        label = "dot_alpha"
    )
    Box(
        modifier = modifier
            .size(10.dp)
            .background(
                if (active) activeColor.copy(alpha = alpha) else TextTertiary.copy(alpha = 0.5f),
                RoundedCornerShape(5.dp)
            )
    )
}

// ── Connection Status Row ─────────────────────────────────────────────────

@Composable
fun ConnectionStatusRow(
    label: String,
    status: String,
    isActive: Boolean,
    icon: ImageVector,
    activeColor: Color = NeonGreen,
    onClick: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (isActive) activeColor else TextTertiary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Text(status, color = if (isActive) activeColor else TextTertiary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
        StatusDot(isActive, activeColor)
    }
}

// ── Neon Button ───────────────────────────────────────────────────────────

@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    color: Color = NeonGreen,
    icon: ImageVector? = null
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(44.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = color.copy(alpha = 0.15f),
            contentColor = color,
            disabledContainerColor = CardDark,
            disabledContentColor = TextTertiary
        ),
        border = BorderStroke(1.dp, if (enabled) color.copy(alpha = 0.6f) else OutlineDark),
        shape = RoundedCornerShape(8.dp)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(
            text,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            letterSpacing = 1.sp
        )
    }
}

// ── Progress Bar ──────────────────────────────────────────────────────────

@Composable
fun NeonProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    color: Color = NeonGreen,
    label: String = ""
) {
    val animProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(500),
        label = "progress"
    )

    Column(modifier = modifier) {
        if (label.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(label, color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Text("${(animProgress * 100).toInt()}%", color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
            Spacer(Modifier.height(4.dp))
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(color.copy(alpha = 0.15f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animProgress)
                    .fillMaxHeight()
                    .background(
                        Brush.horizontalGradient(listOf(color.copy(alpha = 0.7f), color))
                    )
                    .clip(RoundedCornerShape(3.dp))
            )
        }
    }
}

// ── APK Info Card ────────────────────────────────────────────────────────

@Composable
fun ApkInfoCard(
    appName: String,
    packageName: String,
    versionName: String,
    targetSdkVersion: Int,
    apkSizeMb: Float,
    onClear: () -> Unit
) {
    TerminalCard(title = "APK Selecionado", glowColor = NeonBlue) {
        Row(verticalAlignment = Alignment.Top) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    appName,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    packageName,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoChip("v$versionName", NeonBlue)
                    InfoChip("SDK $targetSdkVersion", if (targetSdkVersion < 35) NeonOrange else NeonGreen)
                    InfoChip("${String.format("%.1f", apkSizeMb)} MB", TextSecondary)
                }
            }
            IconButton(onClick = onClear) {
                Icon(Icons.Default.Close, contentDescription = "Remover", tint = TextTertiary)
            }
        }
    }
}

@Composable
fun InfoChip(label: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(label, color = color, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

// ── Log Entry Row ─────────────────────────────────────────────────────────

@Composable
fun LogEntryRow(entry: LogEntry) {
    val (color, prefix) = when (entry.level) {
        LogLevel.DEBUG -> Pair(TextTertiary, "DBG")
        LogLevel.INFO -> Pair(NeonBlue.copy(alpha = 0.8f), "INF")
        LogLevel.WARNING -> Pair(NeonOrange, "WRN")
        LogLevel.ERROR -> Pair(NeonRed, "ERR")
        LogLevel.SUCCESS -> Pair(NeonGreen, "OK ")
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 1.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            "[$prefix][${entry.tag}]",
            color = color.copy(alpha = 0.7f),
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(100.dp)
        )
        Text(
            entry.message,
            color = color,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.weight(1f)
        )
    }
}

// ── Toggle Config Row ─────────────────────────────────────────────────────

@Composable
fun ConfigToggleRow(
    label: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    color: Color = NeonGreen
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = if (checked) TextPrimary else TextSecondary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
            Text(description, color = TextTertiary, fontSize = 10.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = color,
                checkedTrackColor = color.copy(alpha = 0.3f),
                uncheckedThumbColor = TextTertiary,
                uncheckedTrackColor = CardBorderDark
            )
        )
    }
}
