package com.apkpatcher.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Paleta Cyberpunk / Terminal ──────────────────────────────────────────
val NeonGreen = Color(0xFF00FF88)
val NeonGreenDim = Color(0xFF00CC66)
val NeonGreenDark = Color(0xFF004422)
val NeonBlue = Color(0xFF00D4FF)
val NeonPurple = Color(0xFFBD00FF)
val NeonOrange = Color(0xFFFF6B00)
val NeonRed = Color(0xFFFF2244)
val NeonYellow = Color(0xFFFFDD00)

val BackgroundDark = Color(0xFF050A0E)
val SurfaceDark = Color(0xFF0A1520)
val SurfaceVariantDark = Color(0xFF0F1E2E)
val CardDark = Color(0xFF111C28)
val CardBorderDark = Color(0xFF1A3A4A)
val OutlineDark = Color(0xFF1E4060)

val TextPrimary = Color(0xFFE0F4FF)
val TextSecondary = Color(0xFF6B9BB8)
val TextTertiary = Color(0xFF3A6080)

private val DarkColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = Color(0xFF001A0D),
    primaryContainer = NeonGreenDark,
    onPrimaryContainer = NeonGreen,
    secondary = NeonBlue,
    onSecondary = Color(0xFF001A22),
    secondaryContainer = Color(0xFF003344),
    onSecondaryContainer = NeonBlue,
    tertiary = NeonPurple,
    onTertiary = Color(0xFF1A0033),
    error = NeonRed,
    onError = Color(0xFF2A0010),
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondary,
    outline = OutlineDark,
    outlineVariant = CardBorderDark,
)

@Composable
fun ShizukuAPKPatcherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography(),
        content = content
    )
}
