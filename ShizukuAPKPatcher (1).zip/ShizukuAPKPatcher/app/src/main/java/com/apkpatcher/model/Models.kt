package com.apkpatcher.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class ApkInfo(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val versionCode: Long,
    val targetSdkVersion: Int,
    val minSdkVersion: Int,
    val apkPath: String,
    val apkSize: Long,
    val isSystemApp: Boolean = false,
    val permissions: List<String> = emptyList()
) : Parcelable

@Parcelize
data class PatchConfig(
    val targetSdkOverride: Int = 35,
    val bypassSignatureCheck: Boolean = true,
    val allowDowngrade: Boolean = true,
    val grantAllPermissions: Boolean = false,
    val disableVerification: Boolean = true,
    val keepData: Boolean = true,
    val forceQueryable: Boolean = true,
    val bypassRestrictedPermissions: Boolean = true
) : Parcelable

data class PatchJob(
    val id: String,
    val apkInfo: ApkInfo,
    val config: PatchConfig,
    val status: PatchStatus = PatchStatus.QUEUED,
    val progress: Float = 0f,
    val currentStep: String = "",
    val errorMessage: String? = null,
    val outputApkPath: String? = null,
    val startTime: Long = System.currentTimeMillis(),
    val endTime: Long? = null
)

enum class PatchStatus {
    QUEUED,
    DECOMPILING,
    PATCHING_MANIFEST,
    RECOMPILING,
    SIGNING,
    INSTALLING,
    COMPLETED,
    FAILED
}

data class ShizukuConnectionState(
    val isInstalled: Boolean = false,
    val isRunning: Boolean = false,
    val hasPermission: Boolean = false,
    val version: Int = 0
)

data class AdbConnectionState(
    val isConnected: Boolean = false,
    val deviceSerial: String = "",
    val connectionType: AdbConnectionType = AdbConnectionType.NONE,
    val host: String = "localhost",
    val port: Int = 5555
)

enum class AdbConnectionType {
    NONE, USB, WIRELESS, WIRELESS_DEBUG
}

data class InstallResult(
    val success: Boolean,
    val packageName: String,
    val message: String,
    val exitCode: Int
)

sealed class ShellResult {
    data class Success(val output: String, val exitCode: Int = 0) : ShellResult()
    data class Error(val error: String, val exitCode: Int) : ShellResult()
}

data class LogEntry(
    val timestamp: Long = System.currentTimeMillis(),
    val level: LogLevel,
    val tag: String,
    val message: String
)

enum class LogLevel {
    DEBUG, INFO, WARNING, ERROR, SUCCESS
}
