package com.apkpatcher.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apkpatcher.model.*
import com.apkpatcher.ui.components.*
import com.apkpatcher.ui.theme.*
import com.apkpatcher.viewmodel.AdbPairingState
import com.apkpatcher.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val shizukuState by viewModel.shizukuState.collectAsState()
    val adbState by viewModel.adbState.collectAsState()
    val selectedApk by viewModel.selectedApk.collectAsState()
    val patchConfig by viewModel.patchConfig.collectAsState()
    val currentJob by viewModel.currentJob.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val isAnalyzing by viewModel.isAnalyzing.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    // APK file picker
    val apkPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.analyzeApk(it) }
    }

    // Auto-scroll logs
    val logListState = rememberLazyListState()
    LaunchedEffect(logs) {
        if (logs.isNotEmpty()) logListState.animateScrollToItem(0)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        BackgroundDark,
                        Color(0xFF030810),
                        BackgroundDark
                    )
                )
            )
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 24.dp)
        ) {

            // ── Header ────────────────────────────────────────────────
            item {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "◈",
                            color = NeonGreen,
                            fontSize = 22.sp,
                            modifier = Modifier.padding(end = 10.dp)
                        )
                        Column {
                            Text(
                                "SHIZUKU APK PATCHER",
                                color = NeonGreen,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 3.sp
                            )
                            Text(
                                "Android 15 • Privileged Shell • ADB Binder",
                                color = TextTertiary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Divider(color = NeonGreen.copy(alpha = 0.2f), thickness = 1.dp)
                }
            }

            // ── Erro ─────────────────────────────────────────────────
            item {
                AnimatedVisibility(
                    visible = errorMessage != null,
                    enter = slideInVertically() + fadeIn(),
                    exit = slideOutVertically() + fadeOut()
                ) {
                    errorMessage?.let { msg ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = NeonRed.copy(alpha = 0.1f)),
                            border = BorderStroke(1.dp, NeonRed.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = NeonRed, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(msg, color = NeonRed, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                IconButton(onClick = { viewModel.clearError() }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Close, contentDescription = null, tint = NeonRed, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }

            // ── Status de Conexão ─────────────────────────────────────
            item {
                TerminalCard(title = "Status de Conexão", glowColor = NeonGreen) {
                    ConnectionStatusRow(
                        label = "Shizuku",
                        status = when {
                            shizukuState.hasPermission -> "Autorizado • v${shizukuState.version} • uid=2000"
                            shizukuState.isRunning -> "Aguardando permissão"
                            shizukuState.isInstalled -> "Instalado mas não iniciado"
                            else -> "Não instalado"
                        },
                        isActive = shizukuState.hasPermission,
                        icon = Icons.Default.Security,
                        activeColor = NeonGreen,
                        onClick = if (!shizukuState.hasPermission && shizukuState.isRunning) {
                            { viewModel.requestShizukuPermission() }
                        } else null
                    )
                    Divider(color = OutlineDark, modifier = Modifier.padding(vertical = 6.dp))
                    ConnectionStatusRow(
                        label = "ADB Wireless",
                        status = when {
                            adbState.isConnected -> "Conectado • ${adbState.deviceSerial}"
                            else -> "Desconectado"
                        },
                        isActive = adbState.isConnected,
                        icon = Icons.Default.Wifi,
                        activeColor = NeonBlue
                    )

                    if (!shizukuState.hasPermission && !adbState.isConnected) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NeonButton(
                                "Autorizar Shizuku",
                                onClick = { viewModel.requestShizukuPermission() },
                                modifier = Modifier.weight(1f),
                                enabled = shizukuState.isRunning,
                                color = NeonGreen,
                                icon = Icons.Default.Security
                            )
                        }
                    }
                }
            }

            // ── ADB Wireless Debug ────────────────────────────────────
            item {
                AdbWirelessSection(viewModel = viewModel)
            }

            // ── Seleção de APK ────────────────────────────────────────
            item {
                AnimatedContent(
                    targetState = selectedApk,
                    label = "apk_selection"
                ) { apk ->
                    if (apk != null) {
                        ApkInfoCard(
                            appName = apk.appName,
                            packageName = apk.packageName,
                            versionName = apk.versionName,
                            targetSdkVersion = apk.targetSdkVersion,
                            apkSizeMb = apk.apkSize / 1_048_576f,
                            onClear = { viewModel.clearSelectedApk() }
                        )
                    } else {
                        TerminalCard(title = "Selecionar APK", glowColor = NeonBlue) {
                            if (isAnalyzing) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = NeonBlue,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    Text("Analisando APK...", color = NeonBlue, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                                }
                            } else {
                                NeonButton(
                                    "Selecionar APK",
                                    onClick = { apkPicker.launch("application/vnd.android.package-archive") },
                                    modifier = Modifier.fillMaxWidth(),
                                    color = NeonBlue,
                                    icon = Icons.Default.FolderOpen
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "Selecione um APK para descompilar, patcher e reinstalar",
                                    color = TextTertiary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // ── Configurações de Patch ────────────────────────────────
            item {
                PatchConfigSection(
                    config = patchConfig,
                    onConfigChange = { viewModel.updatePatchConfig(it) }
                )
            }

            // ── Botão de Patch / Progresso ────────────────────────────
            item {
                AnimatedContent(
                    targetState = currentJob,
                    label = "patch_button"
                ) { job ->
                    if (job != null) {
                        PatchProgressSection(job = job, onCancel = { viewModel.cancelCurrentJob() })
                    } else {
                        NeonButton(
                            text = "INICIAR PATCH + INSTALAR",
                            onClick = { viewModel.startPatch() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            enabled = selectedApk != null && (shizukuState.hasPermission || adbState.isConnected),
                            color = NeonGreen,
                            icon = Icons.Default.Build
                        )
                    }
                }
            }

            // ── Terminal de Log ───────────────────────────────────────
            item {
                TerminalCard(title = "Log do Sistema", glowColor = TextTertiary) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${logs.size} entradas", color = TextTertiary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        TextButton(onClick = { viewModel.clearLogs() }) {
                            Text("Limpar", color = TextTertiary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                    Spacer(Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .background(Color(0xFF020609), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        if (logs.isEmpty()) {
                            Text(
                                "// Aguardando eventos...",
                                color = TextTertiary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        } else {
                            LazyColumn(state = logListState) {
                                items(logs) { entry ->
                                    LogEntryRow(entry)
                                }
                            }
                        }
                    }
                }
            }

            // ── Shell Interativo ──────────────────────────────────────
            item {
                ShellSection(viewModel = viewModel)
            }

            // ── Histórico ─────────────────────────────────────────────
            if (viewModel.jobHistory.collectAsState().value.isNotEmpty()) {
                item {
                    JobHistorySection(history = viewModel.jobHistory.collectAsState().value)
                }
            }

            item { Spacer(Modifier.height(32.dp)) }
        }
    }
}

// ── ADB Wireless Section ──────────────────────────────────────────────────

@Composable
fun AdbWirelessSection(viewModel: MainViewModel) {
    var expanded by remember { mutableStateOf(false) }
    val adbState by viewModel.adbState.collectAsState()
    val pairingState by viewModel.adbPairingState.collectAsState()
    var adbHost by remember { mutableStateOf("localhost") }
    var adbPort by remember { mutableStateOf("5555") }
    var pairingCode by remember { mutableStateOf("") }
    var pairingPort by remember { mutableStateOf("") }

    TerminalCard(
        title = "ADB Wireless Debug",
        glowColor = if (adbState.isConnected) NeonBlue else TextTertiary
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                if (adbState.isConnected) "Conectado: ${adbState.deviceSerial}"
                else "Configurar conexão ADB wireless",
                color = if (adbState.isConnected) NeonBlue else TextSecondary,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
            Icon(
                if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null,
                tint = TextTertiary,
                modifier = Modifier.size(20.dp)
            )
        }

        AnimatedVisibility(visible = expanded) {
            Column {
                Spacer(Modifier.height(12.dp))
                Divider(color = OutlineDark)
                Spacer(Modifier.height(12.dp))

                // Conexão direta
                Text("Conexão Direta", color = NeonBlue, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = adbHost,
                        onValueChange = { adbHost = it },
                        label = { Text("Host", fontSize = 11.sp) },
                        modifier = Modifier.weight(2f),
                        singleLine = true,
                        colors = textFieldColors()
                    )
                    OutlinedTextField(
                        value = adbPort,
                        onValueChange = { adbPort = it },
                        label = { Text("Porta", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = textFieldColors()
                    )
                }
                Spacer(Modifier.height(8.dp))
                NeonButton(
                    if (adbState.isConnected) "Desconectar" else "Conectar ADB",
                    onClick = {
                        if (adbState.isConnected) viewModel.disconnectAdb()
                        else viewModel.connectAdbWireless(adbHost, adbPort.toIntOrNull() ?: 5555)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    color = NeonBlue,
                    icon = if (adbState.isConnected) Icons.Default.LinkOff else Icons.Default.Link
                )

                Spacer(Modifier.height(12.dp))
                Divider(color = OutlineDark)
                Spacer(Modifier.height(12.dp))

                // Wireless Debug (Android 11+)
                Text("Wireless Debugging (Android 11+)", color = NeonPurple, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Text("Ative em Opções do desenvolvedor → Wireless Debugging", color = TextTertiary, fontSize = 10.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pairingCode,
                        onValueChange = { pairingCode = it },
                        label = { Text("Código de pareamento", fontSize = 10.sp) },
                        modifier = Modifier.weight(2f),
                        singleLine = true,
                        colors = textFieldColors()
                    )
                    OutlinedTextField(
                        value = pairingPort,
                        onValueChange = { pairingPort = it },
                        label = { Text("Porta", fontSize = 10.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = textFieldColors()
                    )
                }
                Spacer(Modifier.height(8.dp))
                NeonButton(
                    "Parear Dispositivo",
                    onClick = { viewModel.pairAdbWirelessDebug(pairingCode, pairingPort.toIntOrNull() ?: 5555) },
                    modifier = Modifier.fillMaxWidth(),
                    color = NeonPurple,
                    enabled = pairingCode.isNotEmpty() && pairingPort.isNotEmpty(),
                    icon = Icons.Default.QrCodeScanner
                )

                // Estado do pareamento
                AnimatedVisibility(visible = pairingState !is AdbPairingState.Idle) {
                    val (msg, color) = when (pairingState) {
                        is AdbPairingState.Connecting -> "Conectando..." to NeonBlue
                        is AdbPairingState.Pairing -> "Pareando..." to NeonPurple
                        is AdbPairingState.Connected -> "Conectado!" to NeonGreen
                        is AdbPairingState.Failed -> "Erro: ${(pairingState as AdbPairingState.Failed).reason}" to NeonRed
                        else -> "" to TextTertiary
                    }
                    if (msg.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(msg, color = color, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

// ── Patch Config Section ──────────────────────────────────────────────────

@Composable
fun PatchConfigSection(config: PatchConfig, onConfigChange: (PatchConfig) -> Unit) {
    var expanded by remember { mutableStateOf(true) }

    TerminalCard(title = "Configurações de Patch", glowColor = NeonOrange) {
        Row(
            modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Parâmetros de instalação", color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Icon(
                if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null, tint = TextTertiary, modifier = Modifier.size(20.dp)
            )
        }

        AnimatedVisibility(visible = expanded) {
            Column {
                Spacer(Modifier.height(8.dp))

                // targetSdkVersion slider
                Text("targetSdkVersion → ${config.targetSdkOverride}", color = NeonOrange, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Slider(
                    value = config.targetSdkOverride.toFloat(),
                    onValueChange = { onConfigChange(config.copy(targetSdkOverride = it.toInt())) },
                    valueRange = 28f..35f,
                    steps = 6,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonOrange,
                        activeTrackColor = NeonOrange,
                        inactiveTrackColor = NeonOrange.copy(alpha = 0.2f)
                    )
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("28", color = TextTertiary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("35 (Android 15)", color = NeonOrange, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }

                Spacer(Modifier.height(8.dp))
                Divider(color = OutlineDark)
                Spacer(Modifier.height(4.dp))

                ConfigToggleRow("Bypass de assinatura", "Desativa verificação de certificado APK", config.bypassSignatureCheck, { onConfigChange(config.copy(bypassSignatureCheck = it)) })
                ConfigToggleRow("Permitir downgrade", "Instala versão mais antiga sem erro", config.allowDowngrade, { onConfigChange(config.copy(allowDowngrade = it)) })
                ConfigToggleRow("Conceder permissões", "Grant todas as runtime permissions", config.grantAllPermissions, { onConfigChange(config.copy(grantAllPermissions = it)) }, NeonBlue)
                ConfigToggleRow("Desativar verificação", "verifier_verify_adb_installs=0", config.disableVerification, { onConfigChange(config.copy(disableVerification = it)) })
                ConfigToggleRow("Preservar dados", "pm uninstall -k mantém dados do app", config.keepData, { onConfigChange(config.copy(keepData = it)) }, NeonGreen)
                ConfigToggleRow("Force queryable", "--force-queryable para visibilidade", config.forceQueryable, { onConfigChange(config.copy(forceQueryable = it)) })
                ConfigToggleRow("Bypass SDK mínimo", "Bypass low targetSdk block no Android 15", config.bypassRestrictedPermissions, { onConfigChange(config.copy(bypassRestrictedPermissions = it)) }, NeonOrange)
            }
        }
    }
}

// ── Patch Progress Section ────────────────────────────────────────────────

@Composable
fun PatchProgressSection(job: PatchJob, onCancel: () -> Unit) {
    TerminalCard(title = "Progresso do Patch", glowColor = NeonYellow) {
        Text(
            job.apkInfo.appName,
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(Modifier.height(8.dp))
        NeonProgressBar(
            progress = job.progress,
            color = NeonYellow,
            label = job.currentStep
        )
        Spacer(Modifier.height(12.dp))

        // Etapas visuais
        val steps = listOf(
            PatchStatus.DECOMPILING to "Descompilando",
            PatchStatus.PATCHING_MANIFEST to "Patching Manifest",
            PatchStatus.RECOMPILING to "Recompilando",
            PatchStatus.SIGNING to "Assinando",
            PatchStatus.INSTALLING to "Instalando"
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            steps.forEach { (status, label) ->
                val isDone = job.progress > (steps.indexOf(status) + 1) * 0.17f
                val isCurrent = job.status == status
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(
                                when {
                                    isDone -> NeonGreen.copy(alpha = 0.3f)
                                    isCurrent -> NeonYellow.copy(alpha = 0.2f)
                                    else -> CardBorderDark
                                },
                                RoundedCornerShape(14.dp)
                            )
                            .border(1.dp, when {
                                isDone -> NeonGreen
                                isCurrent -> NeonYellow
                                else -> OutlineDark
                            }, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (isDone) "✓" else "${steps.indexOf(status) + 1}",
                            color = when {
                                isDone -> NeonGreen
                                isCurrent -> NeonYellow
                                else -> TextTertiary
                            },
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        label,
                        color = when {
                            isDone -> NeonGreen
                            isCurrent -> NeonYellow
                            else -> TextTertiary
                        },
                        fontSize = 7.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        NeonButton("Cancelar", onClick = onCancel, modifier = Modifier.fillMaxWidth(), color = NeonRed, icon = Icons.Default.Stop)
    }
}

// ── Shell Section ─────────────────────────────────────────────────────────

@Composable
fun ShellSection(viewModel: MainViewModel) {
    var expanded by remember { mutableStateOf(false) }
    var command by remember { mutableStateOf("") }
    val shellOutput by viewModel.shellOutput.collectAsState()

    TerminalCard(title = "Shell Interativo", glowColor = TextTertiary) {
        Row(
            modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Executar comandos ADB Shell", color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(20.dp))
        }

        AnimatedVisibility(visible = expanded) {
            Column {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("$ ", color = NeonGreen, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = command,
                        onValueChange = { command = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = textFieldColors(),
                        placeholder = { Text("pm list packages", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = TextTertiary) }
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (command.isNotEmpty()) {
                                viewModel.executeShellCommand(command)
                                command = ""
                            }
                        }
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Executar", tint = NeonGreen)
                    }
                }
                if (shellOutput.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 60.dp, max = 160.dp)
                            .background(Color(0xFF020609), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(shellOutput, color = NeonGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                // Comandos rápidos
                Spacer(Modifier.height(8.dp))
                Text("Comandos rápidos:", color = TextTertiary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.height(4.dp))
                val quickCommands = listOf(
                    "pm list packages" to "Listar pacotes",
                    "getprop ro.build.version.release" to "Versão Android",
                    "id" to "Verificar UID",
                    "settings put global verifier_verify_adb_installs 0" to "Bypass verificação"
                )
                quickCommands.chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { (cmd, label) ->
                            OutlinedButton(
                                onClick = { viewModel.executeShellCommand(cmd) },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                                border = BorderStroke(1.dp, OutlineDark),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                            ) {
                                Text(label, fontSize = 9.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
        }
    }
}

// ── Job History ───────────────────────────────────────────────────────────

@Composable
fun JobHistorySection(history: List<PatchJob>) {
    TerminalCard(title = "Histórico (${history.size})", glowColor = TextTertiary) {
        history.take(5).forEach { job ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val (statusColor, statusIcon) = when (job.status) {
                    PatchStatus.COMPLETED -> NeonGreen to "✓"
                    PatchStatus.FAILED -> NeonRed to "✗"
                    else -> TextTertiary to "·"
                }
                Text(statusIcon, color = statusColor, fontSize = 14.sp, modifier = Modifier.width(20.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(job.apkInfo.appName, color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        if (job.status == PatchStatus.FAILED) "Erro: ${job.errorMessage?.take(40)}" else "SDK ${job.apkInfo.targetSdkVersion} → ${job.config.targetSdkOverride}",
                        color = TextTertiary, fontSize = 10.sp, fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    job.endTime?.let { (it - job.startTime).let { d -> "${d / 1000}s" } } ?: "",
                    color = TextTertiary, fontSize = 10.sp, fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// ── TextField Colors Helper ───────────────────────────────────────────────

@Composable
fun textFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NeonGreen.copy(alpha = 0.7f),
    unfocusedBorderColor = OutlineDark,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextSecondary,
    cursorColor = NeonGreen,
    focusedLabelColor = NeonGreen,
    unfocusedLabelColor = TextTertiary
)
