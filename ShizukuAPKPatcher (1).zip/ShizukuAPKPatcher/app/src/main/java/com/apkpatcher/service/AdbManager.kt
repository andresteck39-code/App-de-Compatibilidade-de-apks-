package com.apkpatcher.service

import android.content.Context
import android.util.Log
import com.apkpatcher.model.AdbConnectionState
import com.apkpatcher.model.AdbConnectionType
import com.apkpatcher.model.ShellResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

/**
 * AdbManager - Gerencia conexão ADB via Wireless Debugging (Android 11+)
 * Implementa protocolo ADB sobre TCP para execução de comandos
 * com privilégios equivalentes ao ADB Shell
 */
class AdbManager(private val context: Context) {

    companion object {
        private const val TAG = "AdbManager"
        private const val DEFAULT_ADB_PORT = 5555
        private const val WIRELESS_DEBUG_PORT = 5037
        const val ADB_KEYS_DIR = "/data/misc/adb"
    }

    private val _connectionState = MutableStateFlow(AdbConnectionState())
    val connectionState: StateFlow<AdbConnectionState> = _connectionState

    private var adbConnection: AdbConnection? = null

    /**
     * Tenta conexão via ADB Wireless Debugging (Android 11+ API 30+)
     * Usa porta padrão 5555 ou porta configurada em developer options
     */
    suspend fun connectWireless(host: String = "localhost", port: Int = DEFAULT_ADB_PORT): Boolean =
        withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "Connecting ADB wireless: $host:$port")

                // Verifica se ADB daemon está ativo via socket
                val socket = Socket()
                socket.connect(InetSocketAddress(host, port), 3000)

                if (socket.isConnected) {
                    socket.close()
                    adbConnection = AdbConnection(host, port)
                    val connected = adbConnection!!.connect()

                    if (connected) {
                        _connectionState.value = AdbConnectionState(
                            isConnected = true,
                            deviceSerial = "$host:$port",
                            connectionType = AdbConnectionType.WIRELESS,
                            host = host,
                            port = port
                        )
                        Log.d(TAG, "ADB Wireless connected: $host:$port")
                        return@withContext true
                    }
                }
                false
            } catch (e: Exception) {
                Log.e(TAG, "ADB wireless connection failed", e)
                false
            }
        }

    /**
     * Conecta via Wireless Debugging (Android 11+ porta 5037 dedicada)
     * Requer que o usuário autorize via notificação ou QR Code
     */
    suspend fun connectWirelessDebug(pairingCode: String, port: Int): Boolean =
        withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "ADB Wireless Debug pairing on port $port")

                // Tenta parear usando o código fornecido
                val pairResult = executeAdbHostCommand("pair localhost:$port $pairingCode")
                if (pairResult.contains("Successfully paired", ignoreCase = true)) {
                    Log.d(TAG, "Pairing successful")

                    // Após pareamento, conecta na porta ADB padrão
                    connectWireless("localhost", DEFAULT_ADB_PORT)
                } else {
                    Log.w(TAG, "Pairing failed: $pairResult")
                    false
                }
            } catch (e: Exception) {
                Log.e(TAG, "Wireless debug connection error", e)
                false
            }
        }

    /**
     * Executa comando shell via ADB
     */
    suspend fun executeShell(command: String): ShellResult = withContext(Dispatchers.IO) {
        if (!_connectionState.value.isConnected) {
            return@withContext ShellResult.Error("ADB não conectado", -1)
        }

        try {
            val result = adbConnection?.executeShell(command)
                ?: return@withContext ShellResult.Error("Conexão ADB perdida", -1)

            if (result.exitCode == 0) {
                ShellResult.Success(result.output, result.exitCode)
            } else {
                ShellResult.Error(result.error, result.exitCode)
            }
        } catch (e: Exception) {
            ShellResult.Error("Erro ADB shell: ${e.message}", -1)
        }
    }

    /**
     * Transfere e instala APK via ADB push + pm install
     */
    suspend fun pushAndInstall(localApkPath: String, config: com.apkpatcher.model.PatchConfig): ShellResult =
        withContext(Dispatchers.IO) {
            try {
                val remotePath = "/data/local/tmp/apkpatcher_install.apk"

                // Push do APK para o dispositivo
                val pushResult = adbConnection?.pushFile(localApkPath, remotePath)
                    ?: return@withContext ShellResult.Error("Conexão ADB indisponível", -1)

                if (!pushResult) {
                    return@withContext ShellResult.Error("Falha no ADB push", -1)
                }

                // Instala via pm
                val installFlags = buildInstallFlags(config)
                val installResult = executeShell("pm install $installFlags $remotePath")

                // Limpa arquivo temporário
                executeShell("rm -f $remotePath")

                installResult
            } catch (e: Exception) {
                ShellResult.Error("Erro no push+install: ${e.message}", -1)
            }
        }

    /**
     * Executa comando no host ADB (adb host protocol)
     */
    private fun executeAdbHostCommand(command: String): String {
        return try {
            val socket = Socket("localhost", 5037)
            val out = socket.getOutputStream()
            val formatted = String.format("%04X%s", command.length, command)
            out.write(formatted.toByteArray())
            out.flush()

            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val result = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                result.appendLine(line)
            }
            socket.close()
            result.toString()
        } catch (e: Exception) {
            Log.e(TAG, "Host command error", e)
            ""
        }
    }

    private fun buildInstallFlags(config: com.apkpatcher.model.PatchConfig): String {
        return buildString {
            append("-t -g -r ")
            if (config.allowDowngrade) append("-d ")
            if (config.forceQueryable) append("--force-queryable ")
            append("--bypass-low-target-sdk-block ")
        }.trim()
    }

    fun isConnected() = _connectionState.value.isConnected

    fun disconnect() {
        adbConnection?.close()
        adbConnection = null
        _connectionState.value = AdbConnectionState()
    }
}

/**
 * AdbConnection - Implementação do protocolo ADB sobre TCP
 * Gerencia handshake, autenticação e streams de comandos
 */
class AdbConnection(private val host: String, private val port: Int) {

    companion object {
        private const val TAG = "AdbConnection"
        private const val ADB_PROTOCOL_MAGIC = "host::"
    }

    private var socket: Socket? = null

    data class ShellOutput(val output: String, val error: String, val exitCode: Int)

    fun connect(): Boolean {
        return try {
            socket = Socket(host, port)
            socket?.soTimeout = 5000
            Log.d(TAG, "ADB socket connected to $host:$port")
            // Aqui entraria o handshake completo do protocolo ADB
            // Simplificado para demonstração - implementação real usa libusb/adb protocol
            true
        } catch (e: Exception) {
            Log.e(TAG, "Socket connect failed", e)
            false
        }
    }

    fun executeShell(command: String): ShellOutput {
        return try {
            // Protocolo ADB shell execution
            val cmd = "shell:$command"
            sendAdbMessage(cmd)
            val output = readAdbResponse()
            ShellOutput(output, "", if (output.contains("Error") || output.contains("error")) 1 else 0)
        } catch (e: Exception) {
            Log.e(TAG, "Shell exec error", e)
            ShellOutput("", e.message ?: "Unknown error", -1)
        }
    }

    fun pushFile(localPath: String, remotePath: String): Boolean {
        return try {
            val file = File(localPath)
            if (!file.exists()) return false

            // ADB sync protocol SEND
            sendAdbMessage("sync:")
            val syncSend = "SEND$remotePath,0644"
            sendAdbData(syncSend.toByteArray())
            sendFileData(file)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Push file error", e)
            false
        }
    }

    private fun sendAdbMessage(service: String) {
        val msg = "host:$service"
        val length = String.format("%04X", msg.length)
        socket?.getOutputStream()?.write("$length$msg".toByteArray())
        socket?.getOutputStream()?.flush()
    }

    private fun sendAdbData(data: ByteArray) {
        socket?.getOutputStream()?.write(data)
        socket?.getOutputStream()?.flush()
    }

    private fun sendFileData(file: File) {
        val buffer = ByteArray(65536)
        file.inputStream().use { input ->
            var bytesRead: Int
            while (input.read(buffer).also { bytesRead = it } != -1) {
                val chunk = buffer.copyOf(bytesRead)
                socket?.getOutputStream()?.write(chunk)
            }
        }
        socket?.getOutputStream()?.flush()
    }

    private fun readAdbResponse(): String {
        val buffer = ByteArray(4096)
        val bytesRead = socket?.getInputStream()?.read(buffer) ?: 0
        return String(buffer, 0, bytesRead)
    }

    fun close() {
        try { socket?.close() } catch (e: Exception) { /* ignore */ }
        socket = null
    }
}
