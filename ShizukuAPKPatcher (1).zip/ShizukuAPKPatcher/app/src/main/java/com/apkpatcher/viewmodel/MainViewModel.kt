package com.apkpatcher.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.apkpatcher.model.*
import com.apkpatcher.service.AdbManager
import com.apkpatcher.service.ApkPatcherEngine
import com.apkpatcher.service.ShizukuManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val shizukuManager = ShizukuManager(application)
    val adbManager = AdbManager(application)
    private val patcherEngine = ApkPatcherEngine(application, shizukuManager, adbManager)

    // ── Estados de conexão ──────────────────────────────────────────────
    val shizukuState: StateFlow<ShizukuConnectionState> = shizukuManager.connectionState
    val adbState: StateFlow<AdbConnectionState> = adbManager.connectionState

    // ── Estado da UI ────────────────────────────────────────────────────
    private val _selectedApk = MutableStateFlow<ApkInfo?>(null)
    val selectedApk: StateFlow<ApkInfo?> = _selectedApk

    private val _patchConfig = MutableStateFlow(PatchConfig())
    val patchConfig: StateFlow<PatchConfig> = _patchConfig

    private val _currentJob = MutableStateFlow<PatchJob?>(null)
    val currentJob: StateFlow<PatchJob?> = _currentJob

    private val _jobHistory = MutableStateFlow<List<PatchJob>>(emptyList())
    val jobHistory: StateFlow<List<PatchJob>> = _jobHistory

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing

    private val _shellOutput = MutableStateFlow<String>("")
    val shellOutput: StateFlow<String> = _shellOutput

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    private val _adbPairingState = MutableStateFlow<AdbPairingState>(AdbPairingState.Idle)
    val adbPairingState: StateFlow<AdbPairingState> = _adbPairingState

    // ── APK Selection ───────────────────────────────────────────────────

    fun analyzeApk(uri: Uri) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            addLog(LogLevel.INFO, "APK", "Analisando APK selecionado...")

            try {
                val apkPath = resolveUriToPath(uri)
                if (apkPath == null) {
                    _errorMessage.value = "Não foi possível acessar o arquivo APK"
                    addLog(LogLevel.ERROR, "APK", "Falha ao resolver URI do APK")
                    return@launch
                }

                val apkInfo = patcherEngine.analyzeApk(apkPath)
                if (apkInfo != null) {
                    _selectedApk.value = apkInfo
                    addLog(LogLevel.SUCCESS, "APK",
                        "APK analisado: ${apkInfo.appName} v${apkInfo.versionName} " +
                        "(targetSdk=${apkInfo.targetSdkVersion})")
                } else {
                    _errorMessage.value = "Falha ao analisar o APK"
                    addLog(LogLevel.ERROR, "APK", "Análise falhou")
                }
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun clearSelectedApk() {
        _selectedApk.value = null
    }

    // ── Patch Config ────────────────────────────────────────────────────

    fun updatePatchConfig(config: PatchConfig) {
        _patchConfig.value = config
    }

    // ── Patch Execution ─────────────────────────────────────────────────

    fun startPatch() {
        val apkInfo = _selectedApk.value ?: run {
            _errorMessage.value = "Nenhum APK selecionado"
            return
        }

        if (!shizukuManager.isAvailable() && !adbManager.isConnected()) {
            _errorMessage.value = "Configure Shizuku ou ADB Wireless para instalar"
            return
        }

        val job = PatchJob(
            id = UUID.randomUUID().toString().take(8),
            apkInfo = apkInfo,
            config = _patchConfig.value
        )

        viewModelScope.launch {
            addLog(LogLevel.INFO, "PATCHER", "Iniciando patch de ${apkInfo.appName}")

            patcherEngine.patchApk(job).collect { updatedJob ->
                _currentJob.value = updatedJob

                when (updatedJob.status) {
                    PatchStatus.DECOMPILING ->
                        addLog(LogLevel.INFO, "PATCHER", "Descompilando APK...")
                    PatchStatus.PATCHING_MANIFEST ->
                        addLog(LogLevel.INFO, "PATCHER", "Patching AndroidManifest.xml (targetSdk → ${_patchConfig.value.targetSdkOverride})")
                    PatchStatus.RECOMPILING ->
                        addLog(LogLevel.INFO, "PATCHER", "Recompilando APK...")
                    PatchStatus.SIGNING ->
                        addLog(LogLevel.INFO, "PATCHER", "Assinando com chave debug...")
                    PatchStatus.INSTALLING ->
                        addLog(LogLevel.INFO, "PATCHER", "Instalando via pm install com bypass flags...")
                    PatchStatus.COMPLETED -> {
                        addLog(LogLevel.SUCCESS, "PATCHER",
                            "✓ ${apkInfo.appName} instalado com sucesso!")
                        _jobHistory.value = listOf(updatedJob) + _jobHistory.value
                        _currentJob.value = null
                        _selectedApk.value = null
                    }
                    PatchStatus.FAILED -> {
                        addLog(LogLevel.ERROR, "PATCHER",
                            "✗ Falha: ${updatedJob.errorMessage}")
                        _jobHistory.value = listOf(updatedJob) + _jobHistory.value
                        _currentJob.value = null
                    }
                    else -> {}
                }
            }
        }
    }

    fun cancelCurrentJob() {
        _currentJob.value = null
        addLog(LogLevel.WARNING, "PATCHER", "Operação cancelada pelo usuário")
    }

    // ── Shell Commands ──────────────────────────────────────────────────

    fun executeShellCommand(command: String) {
        viewModelScope.launch {
            addLog(LogLevel.DEBUG, "SHELL", "$ $command")

            val result = if (shizukuManager.isAvailable()) {
                shizukuManager.executeCommand(command)
            } else if (adbManager.isConnected()) {
                adbManager.executeShell(command)
            } else {
                ShellResult.Error("Sem conexão privilegiada disponível", -1)
            }

            when (result) {
                is ShellResult.Success -> {
                    _shellOutput.value = result.output
                    addLog(LogLevel.SUCCESS, "SHELL", result.output.take(200))
                }
                is ShellResult.Error -> {
                    _shellOutput.value = result.error
                    addLog(LogLevel.ERROR, "SHELL", result.error.take(200))
                }
            }
        }
    }

    // ── Shizuku ─────────────────────────────────────────────────────────

    fun requestShizukuPermission() {
        shizukuManager.requestPermission()
    }

    // ── ADB Wireless ────────────────────────────────────────────────────

    fun connectAdbWireless(host: String = "localhost", port: Int = 5555) {
        viewModelScope.launch {
            _adbPairingState.value = AdbPairingState.Connecting
            addLog(LogLevel.INFO, "ADB", "Conectando ADB wireless $host:$port...")

            val success = adbManager.connectWireless(host, port)
            if (success) {
                _adbPairingState.value = AdbPairingState.Connected
                addLog(LogLevel.SUCCESS, "ADB", "ADB Wireless conectado!")
            } else {
                _adbPairingState.value = AdbPairingState.Failed("Falha ao conectar")
                addLog(LogLevel.ERROR, "ADB", "Falha na conexão ADB wireless")
            }
        }
    }

    fun pairAdbWirelessDebug(code: String, port: Int) {
        viewModelScope.launch {
            _adbPairingState.value = AdbPairingState.Pairing
            addLog(LogLevel.INFO, "ADB", "Pareando via Wireless Debug na porta $port...")

            val success = adbManager.connectWirelessDebug(code, port)
            if (success) {
                _adbPairingState.value = AdbPairingState.Connected
                addLog(LogLevel.SUCCESS, "ADB", "Dispositivo pareado com sucesso!")
            } else {
                _adbPairingState.value = AdbPairingState.Failed("Falha no pareamento")
                addLog(LogLevel.ERROR, "ADB", "Falha no pareamento ADB Wireless Debug")
            }
        }
    }

    fun disconnectAdb() {
        adbManager.disconnect()
        _adbPairingState.value = AdbPairingState.Idle
        addLog(LogLevel.INFO, "ADB", "ADB desconectado")
    }

    // ── Utilities ────────────────────────────────────────────────────────

    private fun resolveUriToPath(uri: Uri): String? {
        return try {
            val context = getApplication<Application>()
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val tempFile = File(context.cacheDir, "temp_apk_${System.currentTimeMillis()}.apk")
            tempFile.outputStream().use { output ->
                inputStream.copyTo(output)
            }
            inputStream.close()
            tempFile.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    private fun addLog(level: LogLevel, tag: String, message: String) {
        val entry = LogEntry(level = level, tag = tag, message = message)
        _logs.value = (listOf(entry) + _logs.value).take(500)
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    fun clearError() {
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        shizukuManager.cleanup()
    }
}

sealed class AdbPairingState {
    object Idle : AdbPairingState()
    object Connecting : AdbPairingState()
    object Pairing : AdbPairingState()
    object Connected : AdbPairingState()
    data class Failed(val reason: String) : AdbPairingState()
}
