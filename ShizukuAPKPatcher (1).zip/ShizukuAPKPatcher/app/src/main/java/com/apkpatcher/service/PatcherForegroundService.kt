package com.apkpatcher.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.apkpatcher.R
import com.apkpatcher.model.PatchJob
import com.apkpatcher.model.PatchStatus
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class PatcherForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "apk_patcher_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START_PATCH = "com.apkpatcher.START_PATCH"
        const val ACTION_CANCEL = "com.apkpatcher.CANCEL"
        const val EXTRA_JOB_ID = "job_id"

        private val _currentJob = MutableStateFlow<PatchJob?>(null)
        val currentJob: StateFlow<PatchJob?> = _currentJob
    }

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var patcherEngine: ApkPatcherEngine? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_PATCH -> {
                startForeground(NOTIFICATION_ID, buildNotification("Iniciando patch..."))
            }
            ACTION_CANCEL -> {
                serviceScope.cancel()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    fun updateProgress(job: PatchJob) {
        _currentJob.value = job
        val message = when (job.status) {
            PatchStatus.DECOMPILING -> "Descompilando APK..."
            PatchStatus.PATCHING_MANIFEST -> "Aplicando patches..."
            PatchStatus.RECOMPILING -> "Recompilando..."
            PatchStatus.SIGNING -> "Assinando APK..."
            PatchStatus.INSTALLING -> "Instalando..."
            PatchStatus.COMPLETED -> "Concluído!"
            PatchStatus.FAILED -> "Erro: ${job.errorMessage}"
            else -> job.currentStep
        }

        val notification = buildNotification(
            message,
            (job.progress * 100).toInt()
        )
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, notification)

        if (job.status == PatchStatus.COMPLETED || job.status == PatchStatus.FAILED) {
            stopSelf()
        }
    }

    private fun buildNotification(message: String, progress: Int = -1): Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("APK Patcher")
            .setContentText(message)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (progress >= 0) {
            builder.setProgress(100, progress, false)
        } else {
            builder.setProgress(0, 0, true)
        }

        return builder.build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "APK Patcher Operations",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Notificações de progresso do patcher de APKs"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}
