// IRemoteService.aidl
package com.apkpatcher;

interface IRemoteService {
    String executeShell(String command);
    boolean installApk(String apkPath, in List<String> flags);
    String getInstalledPackages();
    boolean uninstallPackage(String packageName, boolean keepData);
    String getPackageInfo(String packageName);
}
