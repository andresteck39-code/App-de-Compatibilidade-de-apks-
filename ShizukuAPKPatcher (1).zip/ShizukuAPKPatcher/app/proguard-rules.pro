# Shizuku
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }

# APK Parser
-keep class net.dongliu.apk.parser.** { *; }

# AIDL generated
-keep class com.apkpatcher.IRemoteService { *; }
-keep class com.apkpatcher.IRemoteService$* { *; }

# Kotlin
-keepclassmembers class **$WhenMappings {
    <fields>;
}
