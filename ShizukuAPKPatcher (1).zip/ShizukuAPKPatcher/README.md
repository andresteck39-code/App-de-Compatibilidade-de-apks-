# 🛠️ Shizuku APK Patcher

**Android 15 APK Patching Tool com Privileged ADB Shell via Shizuku Binder e Wireless Debugging**

---

## 📋 Visão Geral

O **Shizuku APK Patcher** é um app Android nativo em Kotlin que utiliza privilégios de ADB Shell para:

- **Descompilar** APKs via extração ZIP + análise AXML
- **Patcher** o `AndroidManifest.xml` binário (AXML) alterando `targetSdkVersion`, flags de segurança, etc.
- **Reinstalar** usando `pm install` com flags de bypass específicas para Android 14/15
- **Executar** comandos shell com `uid=2000` (ADB Shell) via Binder IPC do Shizuku

---

## 🏗️ Arquitetura

```
app/
├── service/
│   ├── ShizukuManager.kt      ← Gerencia Binder IPC com Shizuku
│   ├── AdbManager.kt          ← Conexão ADB Wireless + Wireless Debug
│   ├── ApkPatcherEngine.kt    ← Pipeline de patch: decompile→patch→recompile→install
│   └── PatcherForegroundService.kt
├── viewmodel/
│   └── MainViewModel.kt       ← MVVM coordinator
├── ui/
│   ├── screens/MainScreen.kt  ← UI Compose principal
│   ├── components/Components.kt
│   └── theme/Theme.kt
├── model/Models.kt            ← Data classes
└── aidl/IRemoteService.aidl   ← Interface Binder
```

---

## ⚙️ Métodos de Instalação Privilegiada

### 1. Shizuku (Preferencial)
Usa `ShizukuRemoteProcess` para criar um processo filho com `uid=2000` via Binder IPC:
```kotlin
val process = Shizuku.newProcess(
    arrayOf("sh", "-c", command),
    null, null
)
```

**Flags pm install usadas:**
```bash
pm install -t -g -r -d \
  --no-streaming \
  --force-queryable \
  --bypass-low-target-sdk-block \
  --restrict-permissions \
  <apk>
```

### 2. ADB Wireless Debugging (Android 11+)
Conexão via protocolo ADB sobre TCP na porta 5555 (ou porta configurada).

Para Wireless Debug (Android 11+):
1. Ative **Wireless Debugging** nas Opções do Desenvolvedor
2. Toque em **Parear dispositivo com código de pareamento**
3. Insira o código e porta no app

---

## 🔧 Pipeline de Patch

```
APK Input
    │
    ▼
[1] DECOMPILE (ZipFile extraction)
    │  Extrai todos os recursos e classes para diretório de trabalho
    ▼
[2] PATCH MANIFEST (AXML Binary Patch)
    │  - Modifica targetSdkVersion (Resource ID 0x0101021b)
    │  - Define android:debuggable=true
    │  - Adiciona/modifica configurações de segurança
    ▼
[3] RECOMPILE (ZipOutputStream)
    │  Reempacota todos os arquivos no novo APK
    │  (resources.arsc como STORED, demais DEFLATED)
    ▼
[4] SIGN (apksigner / debug keystore)
    │  Assina com chave debug para permitir instalação
    ▼
[5] INSTALL (pm install via Shizuku/ADB)
    │  pm uninstall -k <package>
    │  pm install -t -g -r -d --bypass-low-target-sdk-block <apk>
    ▼
App instalado com targetSdk=35 ✓
```

---

## 📦 Dependências Principais

| Biblioteca | Versão | Uso |
|-----------|--------|-----|
| `dev.rikka.shizuku:api` | 13.1.5 | Binder IPC privilegiado |
| `dev.rikka.shizuku:provider` | 13.1.5 | Provider para Shizuku |
| `net.dongliu:apk-parser` | 2.6.10 | Parsing de APK e manifesto |
| Jetpack Compose BOM | 2024.02.00 | UI moderna |
| AndroidX Lifecycle | 2.7.0 | ViewModel + StateFlow |

---

## 🚀 Como Usar

### Pré-requisitos
- Android 11+ (API 31 mínimo, API 35 recomendado)
- **Shizuku** instalado e rodando (via ADB USB na primeira vez)
- OU **Wireless Debugging** ativo nas Opções do Desenvolvedor

### Instalação do Shizuku (primeira vez via ADB USB)
```bash
adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh
```

### Setup via Wireless ADB
```bash
# No computador, conectar ao dispositivo
adb tcpip 5555
adb connect <IP_DO_DISPOSITIVO>:5555
# Iniciar Shizuku
adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh
```

### Uso do App
1. Abra o app e autorize o Shizuku (ou conecte via ADB Wireless)
2. Toque em **Selecionar APK** e escolha o arquivo `.apk`
3. Ajuste as configurações (targetSdkVersion, flags de bypass, etc.)
4. Toque em **INICIAR PATCH + INSTALAR**
5. Aguarde o pipeline completar (≈30-120s dependendo do tamanho do APK)

---

## 🔐 Permissões Necessárias

```xml
<uses-permission android:name="moe.shizuku.manager.permission.API_V23" />
<uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
```

---

## ⚠️ Flags de Bypass Android 15

O Android 15 introduziu restrições adicionais para APKs com `targetSdkVersion` baixo:

| Flag | Efeito |
|------|--------|
| `--bypass-low-target-sdk-block` | Ignora bloqueio de SDK mínimo |
| `--force-queryable` | Força visibilidade do pacote |
| `--restrict-permissions` | Contorna novas restrições de permissões |
| `-d` (downgrade) | Permite instalar versão inferior |
| `-g` (grant) | Concede todas as runtime permissions |
| `settings put global verifier_verify_adb_installs 0` | Desativa verificação Google Play Protect |

---

## 📝 Notas Técnicas

### Formato AXML (Android Binary XML)
O `AndroidManifest.xml` dentro de APKs está em formato binário AXML. O patch do `targetSdkVersion` é feito buscando o Resource ID `0x0101021b` no buffer de bytes e sobrescrevendo o valor int32 little-endian subsequente.

### Shizuku vs Root
O Shizuku fornece `uid=2000` (ADB Shell), não `uid=0` (root). Isso é suficiente para `pm install`, `pm uninstall`, `dumpsys`, `settings put global`, mas **não** para operações que requerem root real.

### Segurança
Este app é destinado a desenvolvedores e pesquisadores. Use responsavelmente e apenas em dispositivos que você possui ou tem permissão para modificar.

---

## 🏗️ Build

```bash
# Clone e build
git clone <repo>
cd ShizukuAPKPatcher
./gradlew assembleDebug

# Instalar
adb install app/build/outputs/apk/debug/app-debug.apk
```

**Requisitos:** Android Studio Hedgehog+ / JDK 17 / Gradle 8.2
